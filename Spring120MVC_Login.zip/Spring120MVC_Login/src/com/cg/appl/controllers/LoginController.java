package com.cg.appl.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//http://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class LoginController {

	
	//Give Login.jsp
	@RequestMapping("/login.do")
	public ModelAndView showLoginPage(){
		ModelAndView model= new ModelAndView("login");
		return model;
	}
	
	/*//Do authentication
	@RequestMapping("authenticate.do")
	public ModelAndView authenticate(HttpServletRequest req,HttpServletResponse res){
		
		System.out.println(req.getParameter("username"));
		System.out.println(req.getParameter("password"));
		
		ModelAndView model= new ModelAndView("success");
		return model;
		
	}*/
	
	@RequestMapping("authenticate.do")
	public ModelAndView authenticate(@RequestParam("username") String userName,@RequestParam String password){   
		
		System.out.println(userName);
		System.out.println(password);
		ModelAndView model= new ModelAndView();
		
		if(userName.equals("a") && (password.equals("a"))){
			model.setViewName("success");
			model.addObject("username", userName);
		}else{
			model.addObject("message", "Login Unsuccessful.Please Reenter.");
			model.setViewName("login");
		}
		
		return model;
		
	}
	
	//show main menu or show login page again.
}
