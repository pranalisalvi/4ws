package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeServices;

//http://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class TraineeCrudController {
	private TraineeServices services;
	private  List<String> domainList ;
	private  List<String> locations ;
	
	@PostConstruct
	public void initialize(){
		domainList= new ArrayList<>();
		domainList.add("Java");
		domainList.add(".Net");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locations= new ArrayList<>();
		locations.add("Mumbai");
		locations.add("Pune");
		locations.add("Banglore");
		locations.add("Chennai");
	}
	
	@Resource(name="traineeService")
	public void setTraineeServices(TraineeServices services){
		this.services=services;
	}
	
	
	
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		
		ModelAndView model= new ModelAndView("welcome");
		return model;
	}
	
	

	@RequestMapping("/enterTraineeNo.do")
	public ModelAndView enterTraineeNo(){
		System.out.println("In Controlling method");
		ModelAndView model= new ModelAndView("enterTraineeNo");
		
		
		return model;
	}
	
			//serch by no.
	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam("traineeNo") int traineeNo){   
		
		System.out.println("In Controlling method"+ traineeNo);
		
		ModelAndView model;
		try {
			Trainee trainee= services.getTraineeDetails(traineeNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails",trainee);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
	}
	
			//showAll
	@RequestMapping("/listAllTrainees.do")
	public ModelAndView  listAllTrainees(){
		ModelAndView model=null;
		try {
			List<Trainee> trainees= services.getAllTrainee();
			
			model = new ModelAndView("listAllTrainees");
			model.addObject("trainees",trainees);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
	}
	
			//insert
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm(){
		
		ModelAndView model= new ModelAndView("entryForm");
	
		model.addObject("trainee", new Trainee());  //enter value of trainee that store in trainee object,so create before jsp
		model.addObject("domains", domainList);
		model.addObject("locations",locations );
		return model;
	}
	
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Trainee trainee, BindingResult result){
		
		ModelAndView model= new ModelAndView();
		
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			model.setViewName("entryForm");

			model.addObject("trainee", new Trainee());  //enter value of trainee that store in trainee object,so create before jsp
			model.addObject("domains", domainList);
			model.addObject("locations",locations );
			
			return model;
		}
		try {
			Trainee traineeResponse=services.insertNewTrainee(trainee);
			
			model.setViewName("successInsert");
			model.addObject("trainee", traineeResponse);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", "Record Insertion Failed: "+e.getMessage());
			
		}
		return model;
	}
	
	                 //update
	@RequestMapping("/updateTrainee.do")
	public ModelAndView updateTraineeDetails(@RequestParam("id") int traineeNo){   
		
		System.out.println("In Controlling method"+ traineeNo);
		
		ModelAndView model;
		model= new ModelAndView("error");
		model.addObject("errMsg", "Dummy message");
		
		/*try {
			Trainee trainee= services.getTraineeDetails(traineeNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails",trainee);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}*/
		
		return model;
		
	}
	
	
	
	
}
