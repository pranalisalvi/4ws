package com.cg.appl.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//http://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class EmpController {

	
	//Give Login.jsp
	@RequestMapping("/show.do")
	public ModelAndView showDetailsPage(){
		ModelAndView model= new ModelAndView("show");
		return model;
	}
	
	/*//Do authentication
	@RequestMapping("authenticate.do")
	public ModelAndView authenticate(HttpServletRequest req,HttpServletResponse res){
		
		System.out.println(req.getParameter("username"));
		System.out.println(req.getParameter("password"));
		
		ModelAndView model= new ModelAndView("success");
		return model;
		
	}*/
	
	@RequestMapping("authenticate.do")
	public ModelAndView authenticate(@RequestParam("empId") String empId){   
		
		System.out.println(empId);
		
		ModelAndView model= new ModelAndView();
		
		if(empId.equals("1002")){
			model.setViewName("success");
			model.addObject("empId", empId);
		}else{
			model.addObject("message", "Login Unsuccessful.Please Reenter.");
			model.setViewName("show");
		}
		
		return model;
		
	}
	
	//show main menu or show login page again.
}
