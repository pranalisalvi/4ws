package com.cg.appl.tests;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpQueries {

	public static void main(String[] args) {
		try {
			EmpServices services= new EmpServicesImpl();
			
			List<Emp> empList = services.getEmpOnSal(500, 3000);    //parametrized qry
			for(Emp emp : empList){
				System.out.println(emp);
			}
			
			/*Emp emp= new Emp();             //sequence query
			emp.setEmpNm("Pravin");
			emp.setEmpSal(5000);
			
			emp=services.admitNewEmp(emp);
			System.out.println(emp);*/
			
			/*List<Emp> empList = services.getEmpForComm();    //comm
			for(Emp emp : empList){
				System.out.println(emp);
			}*/
		} catch (EmpExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
