package com.cg.appl.tests;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpServices {

	public static void main(String[] args) {
		try {
			EmpServices services= new EmpServicesImpl();
			/*//1.
			Emp emp= services.getEmpDetails(7499);
			System.out.println(emp);*/
			//2.
			for(Emp emp1:services.getEmpList()){
				System.out.println(emp1);
			}
			
			/*Emp emp= new Emp();
			emp.setEmpNo(1112);
			emp.setEmpNm("aara");
			emp.setEmpSal(5000);
			services.admitNewEmp(emp);
			System.out.println(services.getEmpDetails(1112));
			*/
			//4.
			//services.updateName(1112, "Sara");
			
			//5.
			/*Emp emp= new Emp();
			emp.setEmpNo(1112);
			emp.setEmpNm("a");
			emp.setEmpSal(600);
			services.updateEmp(emp);
			
			//6.
			services.deleteEmp(1112);
			System.out.println(services.deleteEmp(1112));
			*/
			//2.7
			
		} catch (EmpExceptions e) {
			e.printStackTrace();
		}
		
		
	}

}
