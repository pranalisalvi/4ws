package com.cg.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.util.EntityManageUtil;

public class EmpDaoImpl implements EmpDao{
	private EntityManageUtil util;
	private EntityManager manager;
	public EmpDaoImpl() throws EmpExceptions{
		util= new EntityManageUtil();
		manager= util.getManager();
	}
	

	private Emp getEmpDetails(int empNo) throws EmpExceptions {
		Emp emp=manager.find(Emp.class,empNo);
		if(emp==null){
			throw new EmpExceptions("Wrong empNo");
		}
		return emp;
	}
	
	@Override
	public Emp getEmpDetailsSafe(int empNo) throws EmpExceptions {
		Emp emp=manager.find(Emp.class,empNo);
		if(emp==null){
			throw new EmpExceptions("Wrong empNo");
		}
		manager.detach(emp);
		return emp;
	}
	
	
	@Override
	public List<Emp> getEmpList() throws EmpExceptions {
		try {
			//Query qry = manager.createQuery("select e from employee e");
			TypedQuery qry = manager.createNamedQuery("qryAllEmps",Emp.class);
			List<Emp> empList= qry.getResultList();
			
			return empList;
		} catch (Exception e) {
			throw new EmpExceptions("Improper query fabrication",e);
		}
	}
	
	@Override
	public Emp admitNewEmp(Emp emp) throws EmpExceptions {
		try {
			manager.getTransaction().begin();
			manager.persist(emp);
			manager.getTransaction().commit();
		} catch (RollbackException e) {
			throw new EmpExceptions("empNo duplicated");
			//throw new EmpExceptions("Violeted: Column size or Constraint");
		}
		return emp;
	}
	
	@Override
	public boolean updateName(int empNo, String newName) throws EmpExceptions {
		try {
			manager.getTransaction().begin();
			Emp emp= this.getEmpDetails(empNo);
			emp.setEmpNm(newName);
			manager.getTransaction().commit();
			return true;
		} catch (RollbackException e) {
			throw new EmpExceptions("Failed name updation");
		}
	}
	
	@Override
	public boolean updateEmp(Emp emp) throws EmpExceptions {
		try {
		manager.getTransaction().begin();
		
		manager.merge(emp);
		
		System.out.println("####");
		manager.getTransaction().commit();
		return true;
	} catch(RollbackException e) {
		throw new EmpExceptions("Failed name updation");
	}
	}
	
	
	@Override
	public boolean deleteEmp(int empNo) throws EmpExceptions {

		try {
			manager.getTransaction().begin();
			Emp emp=this.getEmpDetails(empNo);
			manager.remove(emp);
			
			System.out.println("####");
			manager.getTransaction().commit();
			return true;
		} catch(RollbackException|EmpExceptions e) {
			throw new EmpExceptions("Failed name updation");
		}
	 
	}

	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws EmpExceptions {
		//String qryStr= "select e from employee e where empSal between :from and :to";  //Parametrized query
		//TypedQuery<Emp> qry=manager.createQuery(qryStr, Emp.class);
		TypedQuery<Emp> qry=manager.createNamedQuery("qryEmpsOnSal", Emp.class);
		qry.setParameter("from", from);
		qry.setParameter("to", to);
		
		return qry.getResultList();
	}


	@Override
	public List<Emp> getEmpForComm() throws EmpExceptions {
		TypedQuery<Emp> qry=manager.createNamedQuery("qryEmpsComm", Emp.class);
		return qry.getResultList();
	}


	
	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}


	
	

	
	

	
	
}
