package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;

public interface EmpServices {
	Emp getEmpDetails(int empNo)throws EmpExceptions;
	List<Emp> getEmpList()throws EmpExceptions;
	Emp admitNewEmp(Emp emp) throws EmpExceptions;
	boolean updateName(int empNo,String newName) throws EmpExceptions;
	boolean updateEmp(Emp emp) throws EmpExceptions;
	boolean deleteEmp(int empNo)throws EmpExceptions; 
	List<Emp> getEmpOnSal(float from,float to) throws EmpExceptions;
	List<Emp> getEmpForComm() throws EmpExceptions;
}
