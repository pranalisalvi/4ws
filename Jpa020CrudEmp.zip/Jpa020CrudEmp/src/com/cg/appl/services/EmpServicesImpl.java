package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.daos.EmpDaoImpl;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;

public class EmpServicesImpl implements EmpServices {
	private EmpDao dao;

	public EmpServicesImpl() throws EmpExceptions {
		dao = new EmpDaoImpl();
	}

	@Override
	public Emp getEmpDetails(int empNo) throws EmpExceptions {

		return dao.getEmpDetailsSafe(empNo);
	}

	@Override
	public List<Emp> getEmpList() throws EmpExceptions {
		
		return dao.getEmpList();
	}

	@Override
	public Emp admitNewEmp(Emp emp) throws EmpExceptions {
		
		return dao.admitNewEmp(emp);
	}

	@Override
	public boolean updateEmp(Emp emp) throws EmpExceptions {
	
		return dao.updateEmp(emp);
	}

	@Override
	public boolean updateName(int empNo, String newName) throws EmpExceptions {
		// TODO Auto-generated method stub
		return dao.updateName(empNo, newName);
	}

	@Override
	public boolean deleteEmp(int empNo) throws EmpExceptions {
		// TODO Auto-generated method stub
		return dao.deleteEmp(empNo);
	}

	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws EmpExceptions {
		
		return dao.getEmpOnSal(from, to);
	}

	@Override
	public List<Emp> getEmpForComm() throws EmpExceptions {
		
		return dao.getEmpForComm();
	}

}
