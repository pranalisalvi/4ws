package com.cg.appl.services;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;

@Component("empService")
public class EmpServicesImpl implements EmpServices {
	private EmpDao dao;
	public  EmpServicesImpl() {
		System.out.println("In Constructor of EmpServicesImpl");
	}
	
	@Resource(name="empDao")
	public void setDao(EmpDao dao) {   //dao
		System.out.println("In setDao()");
		this.dao = dao;
	}



	@Override
	public Emp getEmpDetails(int empNo) throws EmpExceptions {
		Emp emp	=dao.getEmpDetails(empNo);
		return emp;
	}

}
