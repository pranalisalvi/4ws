package com.cg.appl.exceptions;

public class EmpExceptions extends Exception {

	public EmpExceptions() {
		
	}

	public EmpExceptions(String arg0) {
		super(arg0);
		
	}

	public EmpExceptions(Throwable arg0) {
		super(arg0);
		
	}

	public EmpExceptions(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public EmpExceptions(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

}
