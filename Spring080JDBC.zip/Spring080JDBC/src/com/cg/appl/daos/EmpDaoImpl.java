package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.DriverManager; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;


/*Component: for every class
Service: for service class
Repository: for dao class
Controller: for controller classes  of spring MVC
RestControoler: to  declare controller classes for publishing REST services

*/
//@Component("empDao")
//@Repository("empDao")
@Scope("singleton")
public class EmpDaoImpl implements EmpDao {
	private DataSource dataSource;
	
	
	public  EmpDaoImpl() {
		System.out.println("In Constructor of EmpDaoImpl");
	}
	
	@Resource(name="dataSource")
	public void setDataSource(DataSource dataSource) {  
		System.out.println("In setDataSource()");
		this.dataSource= dataSource;
	
	}


	@Override
	public Emp getEmpDetails(int empNo) throws EmpExceptions {
		System.out.println("In getEmpDetails()");
		Connection connect=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String qry= "SELECT EMPNO,ENAME,SAL FROM EMP WHERE EMPNO=?";
		try {
			connect = dataSource.getConnection();
			
			pstmt = connect.prepareStatement(qry);
			pstmt.setInt(1,empNo);
			rs =pstmt.executeQuery();
			
			if(rs.next()){
				Emp emp = new Emp();
				
				emp.setEmpNo(rs.getInt("EMPNO"));
				emp.setEmpNm(rs.getString("ENAME"));
				emp.setEmpSal(rs.getFloat("SAL"));
				
				return emp;
			}
		} catch (SQLException e) {
			throw new EmpExceptions("Problem in DB Handling",e);
			//e.printStackTrace();
		}finally{
			try {
				if(rs!=null){
					rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(connect!=null){
					connect.close();
				}
			} catch (SQLException e) {
				throw new EmpExceptions("Problem in DB Handling",e);
				//e.printStackTrace();
			}
		}
		return null;
	}

}
