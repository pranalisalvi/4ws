package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;


import com.cg.appl.commons.EmployeeDetails;
import com.cg.appl.util.SpringUtil;

public class TestEmployeeDetails {
	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		
		EmployeeDetails details =(EmployeeDetails) ctx.getBean("employeeDetails");
		System.out.println("Employee Id:"+details.getEmpId());
		System.out.println("Employee Name:"+details.getEmpName());
		System.out.println("Employee Salary"+details.getEmpSal());
		System.out.println("Employee BU:"+details.getEmpBu());
		System.out.println("Employee Age:"+details.getAge());
		
	
	}

}

