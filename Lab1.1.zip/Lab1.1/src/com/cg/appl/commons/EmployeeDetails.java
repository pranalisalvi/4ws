package com.cg.appl.commons;

public class EmployeeDetails {
	private int empId;
	private String empName;
	private Double empSal;
	private String empBu;
	private int age;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}

	public String getEmpBu() {
		return empBu;
	}

	public void setEmpBu(String empBu) {
		this.empBu = empBu;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", empBu=" + empBu + ", age=" + age
				+ "]";
	}

}
