package com.cg.appl.controllers;

import java.util.ArrayList; 
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;

import com.cg.appl.services.EmpServices;



//http://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class EmpCrudController {
	private EmpServices services;
	
	
	@PostConstruct
	public void initialize(){
		
	}
	
	@Resource(name="empService")
	public void setEmpServices(EmpServices services){
		this.services=services;
	}
	
	
	
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		
		ModelAndView model= new ModelAndView("welcome");
		return model;
	}
	
	

	@RequestMapping("/enterEmpNo.do")
	public ModelAndView enterEmpNo(){
		System.out.println("In Controlling method");
		ModelAndView model= new ModelAndView("enterEmpNo");
		
		
		return model;
	}
	
			//serch by no.
	@RequestMapping("/getEmpDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam("empNo") int empNo){   
		
		System.out.println("In Controlling method"+ empNo);
		
		ModelAndView model;
		try {
			Emp emp= services.getEmpDetails(empNo);
			model = new ModelAndView("empDetails");
			model.addObject("empDetails",emp);               //object of emp 
		} catch (EmpExceptions e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
	}
	
			//showAll
	@RequestMapping("/listAllEmps.do")
	public ModelAndView  listAllEmps(){
		ModelAndView model=null;
		try {
			model = new ModelAndView("listAllEmps");
			List<Emp> emps= services.getAllEmps();
			model.addObject("emps",emps);
		} catch (EmpExceptions e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
	}
	    //update
	@RequestMapping("/getUpdateForm.do")
	public ModelAndView getEntryForm(@RequestParam("id") int empNo){
		ModelAndView model = null;
		try {
			Emp emp = services.getEmpDetails(empNo);         //after write 3 lines put in try catch
			
			model = new ModelAndView("updateForm");

			model.addObject("emp", emp);
		} catch (EmpExceptions e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		} 
		
		return model;
	}
	
	
	@RequestMapping("/submitUpdateForm.do")
	public String submitEntryForm(@ModelAttribute("emp") @Valid Emp emp, BindingResult result,Model model){
		
		
		
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			
			model.addAttribute("emp", emp);  
			
			return "updateForm";

		}
		try {
			Emp empResponse=services.updateEmp(emp);
			
			
			model.addAttribute("empDetails", empResponse);
			return "successUpdate";
		} catch (EmpExceptions e) {
			
			model.addAttribute("errMsg", "Record update Failed: "+e.getMessage());
			return "error";
		}
		
	}
	
	
			//insert
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm(){
		
		ModelAndView model= new ModelAndView("entryForm");
	
		model.addObject("emp", new Emp());  //enter value of trainee that store in trainee object,so create before jsp
		
		return model;
	}
	
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Emp emp, BindingResult result){
		
		ModelAndView model= new ModelAndView();
		
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			model.setViewName("entryForm");

			model.addObject("emp", new Emp());  //enter value of trainee that store in trainee object,so create before jsp
			
			
			return model;
		}
		try {
			Emp empResponse=services.insertNewEmp(emp);
			
			model.setViewName("successInsert");
			model.addObject("empDetails", empResponse);
		} catch (EmpExceptions e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", "Record Insertion Failed: "+e.getMessage());
			
		}
		return model;
	}
	
	
	@RequestMapping("/getDeleteForm.do")
	public ModelAndView deleteConfirm(@RequestParam("id") int empNo){
		ModelAndView model= null;
		System.out.println("In deleteConfirm: "+empNo);
		try {
			boolean flag= services.deleteEmp(empNo);
			if(flag== true){
			model= new ModelAndView("successDelete");
			
			model.addObject("deleteMsg", "Delete Successful");
			}
		} catch (EmpExceptions e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}
	
	               
	
	
	
}
