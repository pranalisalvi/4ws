package com.cg.appl.services;

import java.util.List; 

import javax.annotation.Resource;



import javax.transaction.Transactional;

import org.springframework.stereotype.Service;



import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;


@Service("empService")
@Transactional
public class EmpServicesImpl implements EmpServices {

	private EmpDao dao;
	
	@Resource(name="empDao")
	public void setEmpDao(EmpDao dao){
		this.dao = dao;
	}
	
	
	@Override
	public Emp getEmpDetails(int empId) throws EmpExceptions {
		
		return dao.getEmpDetails(empId);
	}

	@Override
	public List<Emp> getAllEmps() throws EmpExceptions {
		
		return dao.getAllEmps();
	}

	@Override
	public Emp insertNewEmp(Emp emp) throws EmpExceptions {
		// TODO Auto-generated method stub
		return dao.insertNewEmp(emp);
	}

	@Override
	public Emp updateEmp(Emp emp) throws EmpExceptions {
		// TODO Auto-generated method stub
		return dao.updateEmp(emp);
	}


	@Override
	public boolean deleteEmp(int empId) throws EmpExceptions {
		// TODO Auto-generated method stub
		return dao.deleteEmp(empId);
	}

}
