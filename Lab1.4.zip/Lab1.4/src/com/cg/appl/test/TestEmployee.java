package com.cg.appl.test;



import java.util.List;
import java.util.Scanner;
import org.springframework.context.ConfigurableApplicationContext;
import com.cg.appl.entities.Emp;
import com.cg.appl.service.EmpService;
import com.cg.appl.util.SpringUtil;

public class TestEmployee {

	public static void main(String[] args) {
		
		SpringUtil util=new SpringUtil();
		ConfigurableApplicationContext ctx=(ConfigurableApplicationContext) util.getSpringContext();
		
		EmpService service=ctx.getBean("empService",EmpService.class);
		System.out.println("Input :");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id");
		int eid=sc.nextInt();
		/*List<Emp> eList=service.getEmpDetailOneID(eid);*/
		Emp emp=service.getEmpDetailOneID(eid);
		System.out.println("OutPut :");
		System.out.println("Employee Info : ");
		System.out.println("Employee Id : "+emp.geteId());
		System.out.println("Employee Name : "+emp.geteName());
		System.out.println("Employee Salary : "+emp.getSalary());
		
	
		
	}

}
