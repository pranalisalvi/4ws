package com.cg.appl.collection;


import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;

@Repository("collection")
public class Collection {

	private Map<Integer,Emp> empMap;

	public Map<Integer, Emp> getEmpMap() {
		return empMap;
	}

	public void setEmpMap(Map<Integer, Emp> empMap) {
		this.empMap = empMap;
	}

	@Override
	public String toString() {
		return "Collection [empMap=" + empMap + "]";
	}
	

	
	
}
