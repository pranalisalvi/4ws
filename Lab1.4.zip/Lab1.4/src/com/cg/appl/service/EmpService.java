package com.cg.appl.service;

import java.util.List;

import com.cg.appl.entities.Emp;

public interface EmpService {

	Emp getEmpDetailOneID(int eID);
}
