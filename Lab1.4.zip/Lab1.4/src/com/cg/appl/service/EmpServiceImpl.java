package com.cg.appl.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cg.appl.dao.EmpDao;
import com.cg.appl.entities.Emp;

@Service("empService")
public class EmpServiceImpl implements EmpService {

	EmpDao dao;
	
	@Resource(name="empDao")
	public void setEmpDao(EmpDao dao){
		this.dao=dao;
	}
	
	@Override
	public Emp getEmpDetailOneID(int eID) {
		
		return dao.getEmpDetailOneID(eID);
	}

}
