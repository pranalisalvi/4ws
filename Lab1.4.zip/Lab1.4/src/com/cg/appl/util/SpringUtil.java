package com.cg.appl.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringUtil {

	// SpringContext
	private ApplicationContext context;

	public SpringUtil() {
		context = new ClassPathXmlApplicationContext("CompanyHr.xml");
	}

	public ApplicationContext getSpringContext() {
		return context;
	}

	
	
	
	

}
