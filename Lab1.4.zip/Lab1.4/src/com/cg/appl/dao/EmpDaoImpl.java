package com.cg.appl.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Repository;

import com.cg.appl.collection.Collection;
import com.cg.appl.entities.Emp;
import com.cg.appl.util.SpringUtil;



@Repository("empDao")
public class EmpDaoImpl implements EmpDao {
	Collection collection;
	
	@Resource(name="collection")
	public void setEmpDaoImpl(Collection collection){
		this.collection=collection;
	}
	
	
	@Override
	public Emp getEmpDetailOneID(int eID){
		
		
		Emp emp=collection.getEmpMap().get(eID);
	

		return emp;
		
		
	}
	

	
		
	}

