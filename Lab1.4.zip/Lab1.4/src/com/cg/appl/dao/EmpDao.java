package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.entities.Emp;

public interface EmpDao {
	Emp getEmpDetailOneID(int eID);
}
