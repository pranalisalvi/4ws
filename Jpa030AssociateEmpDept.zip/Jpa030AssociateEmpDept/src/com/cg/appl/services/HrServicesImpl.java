package com.cg.appl.services;

import java.util.List; 





import com.cg.appl.daos.HrDao;
import com.cg.appl.daos.HrDaoImpl;
import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrExceptions;

public class HrServicesImpl implements HrServices {
	private HrDao dao;

	public HrServicesImpl() throws HrExceptions {
		dao = new HrDaoImpl();
	}

	@Override
	public Emp getEmpDetails(int empNo) throws HrExceptions {

		return dao.getEmpDetailsSafe(empNo);
	}

	@Override
	public List<Emp> getEmpList() throws HrExceptions {
		
		return dao.getEmpList();
	}

/*	@Override
	public Emp admitNewEmp(Emp emp) throws HrExceptions {
		
		return dao.admitNewEmp(emp);
	}

	@Override
	public boolean updateEmp(Emp emp) throws HrExceptions {
	
		return dao.updateEmp(emp);
	}

	@Override
	public boolean updateName(int empNo, String newName) throws HrExceptions {
		// TODO Auto-generated method stub
		return dao.updateName(empNo, newName);
	}

	@Override
	public boolean deleteEmp(int empNo) throws HrExceptions {
		// TODO Auto-generated method stub
		return dao.deleteEmp(empNo);
	}*/

	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws HrExceptions {
		
		return dao.getEmpOnSal(from, to);
	}

	@Override
	public List<Emp> getEmpForComm() throws HrExceptions {
		
		return dao.getEmpForComm();
	}

	@Override
	public Dept getDeptDetails(int deptId) throws HrExceptions {
		// TODO Auto-generated method stub
		return dao.getDeptDetails(deptId);
	}

}
