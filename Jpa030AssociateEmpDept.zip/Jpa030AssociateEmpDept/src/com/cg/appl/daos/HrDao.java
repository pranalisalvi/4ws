package com.cg.appl.daos;

import java.util.List; 

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrExceptions;

public interface HrDao  {
	Emp getEmpDetailsSafe(int empNo)throws HrExceptions;
	List<Emp> getEmpList()throws HrExceptions;
	/*Emp admitNewEmp(Emp emp) throws EmpExceptions;
	boolean updateName(int empNo,String newName) throws EmpExceptions;
	boolean updateEmp(Emp emp) throws EmpExceptions;
	boolean deleteEmp(int empNo)throws EmpExceptions; */
	List<Emp> getEmpOnSal(float from,float to) throws HrExceptions;
	List<Emp> getEmpForComm() throws HrExceptions;
	Dept getDeptDetails(int deptId) throws HrExceptions;
}
