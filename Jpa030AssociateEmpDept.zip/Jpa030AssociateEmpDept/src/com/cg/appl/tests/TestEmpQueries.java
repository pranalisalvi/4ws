package com.cg.appl.tests;

import java.util.List;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrExceptions;
import com.cg.appl.services.HrServices;
import com.cg.appl.services.HrServicesImpl;

public class TestEmpQueries {

	public static void main(String[] args) {
		try {
			HrServices services= new HrServicesImpl();
			
			/*List<Emp> empList = services.getEmpOnSal(500, 3000);    //parametrized qry
			for(Emp emp : empList){
				System.out.println(emp);
			}*/
			
			/*Emp emp= new Emp();             //sequence query
			emp.setEmpNm("Pravin");
			emp.setEmpSal(5000);
			
			emp=services.admitNewEmp(emp);
			System.out.println(emp);*/
			
			/*List<Emp> empList = services.getEmpForComm();    //comm
			for(Emp emp : empList){
				System.out.println(emp);
			}*/
			
			//Emp emp= services.getEmpDetails(7499);
			//System.out.println(emp);
			/*
			Dept dept= services.getDeptDetails(emp.getDeptId());
			System.out.println(emp);
			System.out.println(dept);
			
	*/		Emp emp= services.getEmpDetails(7499);
			//System.out.println(emp);
	
	      System.out.println(emp.getDept().getDeptNm());  //unidirctional navigation
	     System.out.println("********************"); 
	      Dept dept= services.getDeptDetails(30);          //bidirctional
	      for(Emp emp1 :dept.getEmps()){
	    	  System.out.println(emp1);
	      }
	      
	      
	     
	     // System.out.println(dept);
		} catch (HrExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
