package com.cg.appl.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity(name="dept")
@Table(name="DEPT")
public class Dept {
	
	@Id
	@Column(name="DEPTNO")
	private int deptId;
	
	@Column(name="DNAME")
	private String deptNm;
	
	@OneToMany(mappedBy="dept")       //copy ownership method propertyName in Emp
	private List<Emp> emps;
	
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptNm() {
		return deptNm;
	}
	public void setDeptNm(String deptNm) {
		this.deptNm = deptNm;
	}
	
	
	public List<Emp> getEmps() {
		return emps;
	}
	
	@Override
	public String toString() {
		return "Dept [deptId=" + deptId + ", deptNm=" + deptNm + "]";
	}
	
	
	
}
