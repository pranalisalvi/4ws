package com.cg.appl.commons;

public class EmployeeDetails {
	private int empId;
	private String empName;
	private Double empSal;
	private int age;
	private SBU businessUnit;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}

	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	
	public void setBusinessUnit(SBU businessUnit) {
		this.businessUnit = businessUnit;
	}
	
	

	public SBU getBusinessUnit() {
		return businessUnit;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", age=" + age + ", businessUnit="
				+ businessUnit + "]";
	}

	

}
