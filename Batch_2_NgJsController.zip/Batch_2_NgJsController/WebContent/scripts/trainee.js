var traineeModule = angular.module("traineeModule",[])

traineeModule.controller("traineesController",
		function($scope){
			$scope.trainees = [
								{
									'traineeId' 	: 'A001',
									'traineeName'   : 'Name Please',
									'domain' 		: 'Java',
									'location' 		: 'Mumbai'
									
								},
			                   
								
								{
									'traineeId' 	: 'A002',
									'traineeName' 	: 'Name Please',
									'domain' 		: 'DotNet',
									'location' 		: 'Pune'
									
							    },
							    
							    {
									'traineeId' 	: 'A003',
									'traineeName' 	: 'Name Please',
									'domain' 		: 'Python',
									'location' 		: 'Bengluru'
									
							    }
			                   
			                   
			                   ];
			
			
			}

);

traineeModule.controller("traineeController",
		function($scope){
			$scope.trainee= {
					'traineeName' : "Name Please",
					'domain' : "",
					'location' : ""
					
			};
			
			$scope.domains = [
		                  		'Java','DotNet','Python','Scala'
		                  ];
		
			$scope.locations = [
		                    	'Mumbai','Pune','Chennai','Delhi','Kolkata'
		                    ];
		
	
       }






);
