package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;



import com.cg.appl.commons.EmployeeDetails;
import com.cg.appl.commons.SBU;
import com.cg.appl.util.SpringUtil;

public class TestEmployeeDetails {
	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		
		SBU bu= (SBU) ctx.getBean("sbu");
		System.out.println("SBU Code:"+bu.getSbuId());
		System.out.println("SBU Name:"+bu.getSbuName());
		System.out.println("SBU Head:"+bu.getSbuHead());
		System.out.println("Employee Details:"+bu.getEmpList());
	
	}

}

