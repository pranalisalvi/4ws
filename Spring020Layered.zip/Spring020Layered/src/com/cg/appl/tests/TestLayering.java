package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.services.EmpServices;
import com.cg.appl.util.SpringUtil;

public class TestLayering {

	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		System.out.println("******************************");
		
		EmpServices empServices = ctx.getBean("empService", EmpServices.class);
		
		try {
			empServices.getEmpDetails();
		} catch (EmpExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
