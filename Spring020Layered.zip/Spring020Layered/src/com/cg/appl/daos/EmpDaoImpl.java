package com.cg.appl.daos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.util.EntityManageUtil;

/*Component: for every class
Service: for service class
Repository: for dao class
Controller: for controller classes  of spring MVC
RestController: to  declare controller classes for publishing REST services

*/
//@Component("empDao")
@Repository("empDao")
@Scope("singleton")
public class EmpDaoImpl implements EmpDao {
	private EntityManageUtil util;
	
	public  EmpDaoImpl() {
		System.out.println("In Constructor of EmpDaoImpl");
	}
	

	@Autowired     //autowiring by type
	@Quaqlifier("dbUtil")
	public void setUtil(EntityManageUtil util) {  //util
		System.out.println("In setUtil()");
		this.util = util;
	
	}


	@Override
	public Emp getEmpDetails() throws EmpExceptions {
		System.out.println("In getEmpDetails()");
		return null;
	}

}
