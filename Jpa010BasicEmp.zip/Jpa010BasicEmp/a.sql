create sequence emp_seq start with 1 increment by 1;

select * from emp;

select * from emp where comm> 0;