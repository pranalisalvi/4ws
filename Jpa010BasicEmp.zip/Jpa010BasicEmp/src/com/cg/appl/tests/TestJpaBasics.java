package com.cg.appl.tests;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.appl.entities.Emp;

public class TestJpaBasics {

	public static void main(String[] args) {
		//1. Create entity manager factory. Makes DS, ConnectPool ,Cache-2  ready.
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		
		//2.Create entity manager. Makes Cache-1, dialect ready
		EntityManager manager= factory.createEntityManager();
		
		//3.Get a single record.
		/*Emp emp=manager.find(Emp.class,7499);
		System.out.println(emp);*/
		
		//To get multiple record.
		Query qry= manager.createQuery("SELECT e FROM employee as e where empSal >=2500"); //'Emp' name of class,so called object targeting query  And empSal is property name
		List<Emp>empList= qry.getResultList();
		
		for(Emp emp:empList){
			System.out.println(emp);
		}
		
		//4.Close Resources.
		manager.close();
		factory.close();
	}

}
