package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.commons.CompanyDetails;
import com.cg.appl.entities.Emp;
import com.cg.appl.util.SpringUtil;

public class TestScope {
	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		System.out.println("*******************************");
		CompanyDetails companyDetails1= ctx.getBean("companyDetails",CompanyDetails.class);
		CompanyDetails companyDetails2= ctx.getBean("companyDetails",CompanyDetails.class);
		
		System.out.println(companyDetails1.hashCode());
		System.out.println(companyDetails2.hashCode());
		System.out.println(companyDetails1);
		
		Emp emp1= ctx.getBean("emp",Emp.class);
		Emp emp2= ctx.getBean("emp",Emp.class);
		
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
		
}
}