package com.cg.appl.services;

import java.util.List; 

import com.cg.appl.entities.Emp;

import com.cg.appl.exceptions.EmpExceptions;


public interface EmpServices {
	Emp insertNewEmp(Emp emp) throws EmpExceptions;
	List<Emp> getAllEmps() throws EmpExceptions;
	
	
}
