package com.cg.appl.controllers;

import java.util.ArrayList; 
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.services.EmpServices;




@Controller
public class EmpCrudController {
	private EmpServices services;
	private  List<String> designations ;
	
	@PostConstruct
	public void initialize(){
		designations= new ArrayList<>();
		designations.add("Software Engineer");
		designations.add("Senior Software Engineer");
		designations.add("Team Lead");
		designations.add("Manager");
		
	}
	
	@Resource(name="empService")
	public void setEmpServices(EmpServices services){
		this.services=services;
	}
	
	
	
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		
		ModelAndView model= new ModelAndView("welcome");
		return model;
	}
	
	

	//insert
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm(){
		
		ModelAndView model= new ModelAndView("entryForm");
	
		model.addObject("emp", new Emp());
		model.addObject("designations",designations );
		
		return model;
	}
	
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Emp emp, BindingResult result){
		
		ModelAndView model= new ModelAndView();
		
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			model.setViewName("entryForm");

			model.addObject("emp", new Emp());  
			model.addObject("designations",designations );
			
			
			return model;
		}
		try {
			Emp empResponse=services.insertNewEmp(emp);
			
			model.setViewName("successInsert");
			model.addObject("empDetails", empResponse);
		} catch (EmpExceptions e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", "Record Insertion Failed: "+e.getMessage());
			
		}
		return model;
	}
	
			//showAll
	@RequestMapping("/listAllEmps.do")
	public ModelAndView  listAllEmps(){
		ModelAndView model=null;
		try {
			model = new ModelAndView("listAllEmps");
			List<Emp> emps= services.getAllEmps();
			model.addObject("emps",emps);
		} catch (EmpExceptions e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
	}
	    
	
		
	
	

	
}
