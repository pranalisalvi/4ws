package com.cg.appl.entities;

import java.io.Serializable; 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="employee")
@Table(name="employee")
@NamedQueries({
	    
		 @NamedQuery(name="qryAllEmps", query="select e from employee e"),
		
		})

@SequenceGenerator(name="emp_generate", sequenceName= "hibernate_sequence", allocationSize=1, initialValue=1001)	
public class Emp implements Serializable {
	private int empNo;
	private String empNm;
	private String gender;
	private String designationNm;
	private String email;
	private String phoneNo;
	
	@Id
	@Column(name="employee_code")
	@GeneratedValue(generator="emp_generate", strategy= GenerationType.SEQUENCE)
	public int getEmpNo() {       //empNo 
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	
	@Column(name="employee_name")
	@NotEmpty(message="Name is mandatory")
	@Size(min=3, max=10, message="Minimum 3 and maximum 40 characters")
	public String getEmpNm() {    //empNm
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	
	@Column(name="employee_gender")
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@Column(name="designation_name")
	public String getDesignationNm() {
		return designationNm;
	}
	public void setDesignationNm(String designationNm) {
		this.designationNm = designationNm;
	}
	
	@Column(name="employee_email")
	@Email(message="email should be validated")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name="employee_phone")
	@Size(min=10, max=10, message="Phone should be 10 digits")
	@Pattern(regexp="[7|8|9]{1}[0-9]{9}")
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", gender="
				+ gender + ", designationNm=" + designationNm + ", email="
				+ email + ", phoneNo=" + phoneNo + "]";
	}
	

	
}
