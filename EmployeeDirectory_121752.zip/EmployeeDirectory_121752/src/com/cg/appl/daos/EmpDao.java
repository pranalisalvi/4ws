package com.cg.appl.daos;

import java.util.List; 

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;



public interface EmpDao {
	Emp insertNewEmp(Emp emp) throws EmpExceptions;
	List<Emp> getAllEmps() throws EmpExceptions;
	
}	
