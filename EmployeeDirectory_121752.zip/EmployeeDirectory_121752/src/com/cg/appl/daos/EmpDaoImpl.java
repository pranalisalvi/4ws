package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;

@Repository("empDao")
public class EmpDaoImpl implements EmpDao {

	@PersistenceContext
	private EntityManager manager;

	
	@Override
	public Emp insertNewEmp(Emp emp) throws EmpExceptions {
		manager.persist(emp);
		return emp;
	}

	@Override
	public List<Emp> getAllEmps() throws EmpExceptions {
		Query qry = manager.createNamedQuery("qryAllEmps", Emp.class);
		return qry.getResultList();
	}

}
